import requests
from json import dumps
payload = {'title': 'restful services',
           'description': 'restful implementation using flask'}

res = requests.post('http://127.0.0.1:5000/todo/api/tasks',
                    json=payload)
print res.content
print res.status_code