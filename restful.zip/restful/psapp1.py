from flask import Flask
from time import ctime

app = Flask(__name__)

@app.route('/home')
def index():
    return "<h1>{}</h1>".format(ctime())


if __name__ == '__main__':
    app.run(host='localhost', port=1236)