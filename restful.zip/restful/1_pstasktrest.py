from flask import Flask, jsonify, abort, request

app = Flask(__name__)

tasks = [
    {
        'id': 1,
        'title': u'pay fee',
        'description': u'paying processing fee',
        'done': True
    },
    {
        'id': 2,
        'title': u'Learn Python',
        'description': u'writing restful service using Python',
        'done': False
    },
]

@app.route('/todo/api/tasks', methods=['POST'])
def create_task():
    print request.json
    if not request.json or 'title' not in request.json:
        abort(404)

    task = {
        'id': tasks[-1]['id'] + 1,
        'title': request.json['title'],
        'description': request.json.get('description', ''),
        'done': False
    }

    tasks.append(task)
    return jsonify({'task': task}), 200

@app.route('/todo/api/tasks/<int:task_id>', methods=['GET'])
def get_task(task_id):
    task = [task for task in tasks if task['id'] == task_id]

    if len(task) == 0:
        abort(404)

    return jsonify({'task': task})


@app.route('/todo/api/tasks', methods=['GET'])
def get_tasks():
    return jsonify({'tasks': tasks})

if __name__ == '__main__':
    app.run()