MESSAGES = {
    'default': 'Hello to the World of Flask!',
}
