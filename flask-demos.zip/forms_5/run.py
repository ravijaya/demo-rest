from my_app import app
app.run(debug=True)
